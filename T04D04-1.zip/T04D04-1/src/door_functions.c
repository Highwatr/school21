#include <math.h>
#include <stdio.h>

double w_agnesi(double x);
double bernulli(double x);
double gip(double);

int main(void) {
    int itr = 42;
    double step;
    double point;
    const double pi = 3.14159265358979323846;

    point = -pi;
    step = (pi - (-pi)) / (itr - 1);

    for (int i = 1; i <= itr; i++) {
        if (point * point >= 2) {
            printf("%.7lf | %.7lf | - | %.7lf\n", point, w_agnesi(point), gip(point));
        } else {
            printf("%.7lf | %.7lf | %.7lf | %.7lf\n", point, w_agnesi(point), bernulli(point), gip(point));
        }
        point = point + step;
    }

    return 0;
}

double w_agnesi(double x) {
    double y;

    y = 1 / (x * x);

    return y;
}

double bernulli(double x) {
    double y;

    y = sqrt(sqrt(1 + 4 * x * x) - x * x - 1);

    return y;
}

double gip(double x) {
    double y;

    y = 1 / (x * x);

    return y;
}