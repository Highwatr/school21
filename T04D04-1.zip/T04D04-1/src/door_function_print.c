#include <math.h>
#include <stdio.h>

#define NUM_POINTS 42
#define MAX_HEIGHT 21

double w_agnesi(double x);
double bernulli(double x);
double gip(double);
void draw_graph();

int main(void) {
    int itr = 42;
    double step;
    double point;
    const double pi = 3.14159265358979323846;

    point = -pi;
    step = (pi - (-pi)) / (itr - 1);

    for (int i = 1; i <= itr; i++) {
        if (point * point >= 2) {
            printf("%.7lf | %.7lf | - | %.7lf\n", point, w_agnesi(point), gip(point));
        } else {
            printf("%.7lf | %.7lf | %.7lf | %.7lf\n", point, w_agnesi(point), bernulli(point), gip(point));
        }
        point = point + step;
    }
    draw_graph();

    return 0;
}

double w_agnesi(double x) {
    double y;

    y = 1 / (x * x);

    return y;
}

double bernulli(double x) {
    double y;

    y = sqrt(sqrt(1 + 4 * x * x) - x * x - 1);

    return y;
}

double gip(double x) {
    double y;

    y = 1 / (x * x);

    return y;
}
void draw_graph() {
    const double pi = 3.14159265358979323846;

    for (int y = MAX_HEIGHT; y >= -MAX_HEIGHT; y--) {
        for (int x = -NUM_POINTS / 2; x < NUM_POINTS / 2; x++) {
            double x_val = -pi + (2 * pi * (x + NUM_POINTS / 2) / (NUM_POINTS - 1));
            if (round(w_agnesi(x_val) * MAX_HEIGHT) == y) {
                printf("*");
            }
            printf(" ");
        }
        printf("\n");
    }

    for (int y = MAX_HEIGHT; y >= -MAX_HEIGHT; y--) {
        for (int x = -NUM_POINTS / 2; x < NUM_POINTS / 2; x++) {
            double x_val = -pi + (2 * pi * (x + NUM_POINTS / 2) / (NUM_POINTS - 1));
            if (round(bernulli(x_val) * MAX_HEIGHT) == y) {
                printf("*");
            }
            printf(" ");
        }
        printf("\n");
    }

    for (int y = MAX_HEIGHT; y >= -MAX_HEIGHT; y--) {
        for (int x = -NUM_POINTS / 2; x < NUM_POINTS / 2; x++) {
            double x_val = -pi + (2 * pi * (x + NUM_POINTS / 2) / (NUM_POINTS - 1));
            if (round(gip(x_val) * MAX_HEIGHT) == y) {
                printf("*");
            } else {
                printf(" ");
            }
            printf(" ");
        }
        printf("\n");
    }
}