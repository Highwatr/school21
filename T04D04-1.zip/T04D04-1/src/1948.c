#include <stdio.h>

int isPrime(int num);
int npd(int x);

int main(void) {
    char ch;
    int a;

    if ((scanf("%d", &a) != 1) && (scanf("%c", &ch) == 1)) {
        printf("n/a\n");
    } else {
        printf("%d\n", npd(a));
    }

    return 0;
}

int isPrime(int num) {
    int flag;
    int temp;

    flag = 1;
    if (num <= 1) flag = 0;
    for (int i = 2; i * i <= num; i++) {
        temp = num;  // Сохраним значение в temporay variable
        while (temp > 0) {
            temp = temp - i;  // Вычитаем i из temp, пока оно положительно
        }
        if (temp == 0) flag = 0;  // Если можем вычесть до 0, значит, num делится на i
    }

    return flag;
}

int npd(int x) {
    int lPrime = -1;  // Инициализация переменной для хранения результата
    int temp;

    if (x < 0) x = -x;
    if (x == 0) {
        printf("n/a\n");
    } else {
        for (int i = 2; i <= x; i++) {  // Проверяем делимость чисел, начиная с 2
            if (isPrime(i)) {
                temp = x;  // Временная переменная для вычитания
                while (temp >= i) {
                    temp = temp - i;
                }
                if (temp == 0) {  // Если temp равно 0, значит, i является делителем
                    lPrime = i;
                }
            }
        }
    }

    return lPrime;
}