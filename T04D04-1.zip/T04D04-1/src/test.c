#include <stdio.h>

int main(void) {
    int a;
    int b;
    int count;
    char ch2;
    char ch3;

    count = scanf("%d %d%c%c", &a, &b, &ch2, &ch3);

    printf("Вывод:\n(1)%d\n(2)%d\n(3)%c\n(4)%c\ncount %d\n", a, b, ch2, ch3, count);

    return 0;
}
