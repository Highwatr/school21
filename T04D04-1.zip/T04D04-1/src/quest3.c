#include <stdio.h>

int fib(int n);

int main(void) {
    int n;
    char ch;

    if (scanf("%d%c", &n, &ch) == 2 && ch == '\n') {
        printf("%d", fib(n));
    } else {
        printf("n/a");
    }

    return 0;
}

int fib(int n) {
    int f;

    if (n == 0) {
        f = 0;
    } else {
        if (n == 1) {
            f = 1;
        } else {
            f = fib(n - 1) + fib(n - 2);
        }
    }
    return f;
}