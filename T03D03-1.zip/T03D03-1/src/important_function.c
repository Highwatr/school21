#include <math.h>
#include <stdio.h>

double func(double a);

int main(void) {
    double x;
    char ch;

    if ((scanf("%lf", &x) != 1) && (x <= 0) && (scanf("%c", &ch) == 1)) {
        printf("n/a\n");
    } else {
        printf("%.1lf\n", func(x));
    }

    return 0;
}

double func(double a) {
    double y;
    double ex1;
    double ex2;
    double ex3;
    double ex4;

    ex1 = 0.007 * pow(a, 4);
    ex2 = (22.8 * pow(a, 1.0 / 3) - 1000) * a + 3;
    ex3 = pow(a, 2) / 2;
    ex4 = a * pow((10 + a), 2.0 / a);
    y = ex1 + ex2 / ex3 - ex4 - 1.01;

    return y;
}