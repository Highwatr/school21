#include <stdio.h>

int main(void) {
    int int_name;

    scanf("%d", &int_name);
    printf("Hello, %d!\n", int_name);

    return 0;
}