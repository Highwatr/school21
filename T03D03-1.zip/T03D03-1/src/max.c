#include <stdio.h>

int max_num(int a, int b);

int main(void) {
    int a;
    int b;
    char ch;

    if ((scanf("%d %d", &a, &b) != 2) || (scanf("%c", &ch) == 1 && ch != '\n')) {
        printf("n/a\n");
    } else {
        printf("%d\n", max_num(a, b));
    }

    return 0;
}

int max_num(int a, int b) {
    int max;

    max = b;
    if (a > b) {
        max = a;
    }

    return max;
}
