#include <stdio.h>

int main(void) {
    int a;
    int b;
    char ch;

    if ((scanf("%d %d", &a, &b) != 2) || (scanf("%c", &ch) == 1 && ch != '\n')) {
        printf("n/a\n");
    } else {
        if (b != 0) {
            printf("%lld %lld %lld %lld\n", (long long int)a + b, (long long int)a - b, (long long int)a * b,
                   (long long int)a / b);
        } else {
            printf("%lld %lld %lld n/a\n", (long long int)a + b, (long long int)a - b, (long long int)a * b);
        }
    }

    return 0;
}