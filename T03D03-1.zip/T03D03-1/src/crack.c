#include <stdio.h>

int point(double x, double y);

int main(void) {
    double x;
    double y;
    char ch;

    if ((scanf("%lf %lf", &x, &y) != 2) && (scanf("%c", &ch) == 1)) {
        printf("n/a\n");
    } else {
        if (point(x, y)) {
            printf("GOTCHA\n");
        } else {
            printf("MISS\n");
        }
    }

    return 0;
}

int point(double x, double y) {
    int flag = 0;

    if (x * x + y * y < 25) {
        flag = 1;
    }

    return flag;
}
