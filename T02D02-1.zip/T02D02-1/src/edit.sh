#!/bin/bash

if [ &# != 3]; then
	echo "Ошибка: не хватает параметров"
	exit 1
fi

if [ ! -e $1 ]; then
	echo "Ошибка: файл $1 не существует"
	exit 1
fi

if [ $2 == $3 ]; then
	echo "Ошибка: файл не изменился"
	exit 1
fi

sed -i "s/$2/$3/g" $1

file_size=$(stat -c%s "$1")
last_mod_date=$(ls -l --time-style=long-iso "$1" | awk '{print $6, $7}')
sha_sum=$(sha256sum "$1" | awk '{print $1}')
log_string="src/$1 - $file_size - $last_mod_date - $sha_sum - sha256"

echo "$log_string" >> files.log