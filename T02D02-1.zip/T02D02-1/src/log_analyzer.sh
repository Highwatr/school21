#!/bin/bash

if [ -z $1 ]; then 
    echo "Ошибка: нет файла"
    exit 1
fi 

if [ -f $1 ]; then 
    count_rec=$( awk '{print $1}' $1 | wc -l )
    uniq_rec=$( awk '{print $8}' $1 | sort | uniq | wc -l)
    hash_rec=$( awk ' NR > 1 {print $1}' $1 | sort | wc -l)
    echo "Количество записей - $count_rec"
    echo "Количество уникальных записей - $uniq_rec"
    echo "Количество изменений - $hash_rec"
else
    echo "Ошибка: файл не существует"
fi