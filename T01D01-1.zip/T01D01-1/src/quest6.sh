 bash ai_help/keygen.sh 
 rm ./key/file*
 bash ai_help/unifier.sh 
 mv main.key ai_help/
 mv key/ ai_help/