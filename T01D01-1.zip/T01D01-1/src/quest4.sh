kill `pgrep ai_door_control` 
